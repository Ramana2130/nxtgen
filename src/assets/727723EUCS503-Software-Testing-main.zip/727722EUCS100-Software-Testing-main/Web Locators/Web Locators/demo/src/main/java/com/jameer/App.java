package com.jameer;

import org.checkerframework.checker.units.qual.h;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By.ByLinkText;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

import com.github.dockerjava.api.model.Driver;

import io.github.bonigarcia.wdm.WebDriverManager;
import io.github.bonigarcia.wdm.webdriver.WebDriverBrowser;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )throws Exception
    {
        
      //      Thread.sleep(3000);
      //   driver.findElement(By.xpath("/html/body/div[6]/div/div[2]/button")).click();;
      //     Thread.sleep(2000);

      //     driver.findElement(By.xpath("/html/body/div[3]/div/div/div[2]/form/div[1]/input")).sendKeys("JAMEER HUSSAIN A");
      //  Thread.sleep(2000);
      //  driver.findElement(By.xpath("/html/body/div[3]/div/div/div[2]/form/div[2]/input")).sendKeys("INDIA");
      //  Thread.sleep(2000);
      //  driver.findElement(By.xpath("/html/body/div[3]/div/div/div[2]/form/div[3]/input")).sendKeys("TRICHY");;
      //  Thread.sleep(2000);
      //  driver.findElement(By.xpath("/html/body/div[3]/div/div/div[2]/form/div[4]/input")).sendKeys("9876567856");;
      //  Thread.sleep(2000);
      //  driver.findElement(By.xpath("/html/body/div[3]/div/div/div[2]/form/div[5]/input")).sendKeys("MARCH");;
      //  Thread.sleep(2000);
      //  driver.findElement(By.xpath("/html/body/div[3]/div/div/div[2]/form/div[6]/input")).sendKeys("2024");;
      //  Thread.sleep(2000);
      //  driver.findElement(By.xpath("/html/body/div[3]/div/div/div[3]/button[2]")).click();
      //  Thread.sleep(5000);

      // driver.findElement(By.xpath("/html/body/div[10]/div[7]/div/button")).click();
      
     










        //  driver.findElement(By.xpath("/html/body/div[1]/div/div[1]/div/div/div/div/div[1]/div/div[1]/div/div[1]/div[1]/header/div[1]/div[2]/form/div/div/input")).sendKeys("java");;
       // driver.findElement(By.xpath(//*[@id="container"]/div/div[1]/div/div/div/div/div[1]/div/div[1]/div/div[1]/div[1]/header/div[1]/div[2]/form/div/div/input)).sendk;   // driver.findElement(By.className("gm-padding"));
        // String pi=driver.getCurrentUrl();
        // System.out.println(pi);
        // Thread.sleep(5000);
        // driver.findElement(By.id(""));
        // String FLIPKART_PATH="https://www.flipkart.com/";

        // String GOOGLE="https:/www.google.com";

        //  driver.get(FLIPKART_PATH);
        //  Thread.sleep(3000);
        //  driver.get(GOOGLE);
         
       
    // //    driver.navigate().to(FLIPKART_PATH);
    //     driver.navigate().to(GOOGLE);
    //     driver.navigate().to(FLIPKART_PATH);
    // // driver.quit();
    //   //
    //   driver.findElement(By.className("gLFyf")).sendKeys("geeksforgeeks");;
    //   // driver.navigate().refresh();
    }
}
